import React from 'react'

export default function SavedJobs() {
    

    return (
        <>
            SavedJobs
        </>
    )
}
