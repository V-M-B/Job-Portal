import React from 'react'

export default function Job() {
    

    return (
        <>
            job
        </>
    )
}
