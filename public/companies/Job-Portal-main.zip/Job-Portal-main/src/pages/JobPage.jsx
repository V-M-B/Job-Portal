import React from 'react'

export default function JobPage() {
    

    return (
        <>
            JobPage
        </>
    )
}
